//**************************************************************************/
// Copyright (c) 1998-2008 Autodesk, Inc.
// All rights reserved.
// 
//  Use of this software is subject to the terms of the Autodesk license 
//  agreement provided at the time of installation or download, or which 
//  otherwise accompanies this software in either electronic or hard copy form.
//**************************************************************************/
// AUTHOR: Benjamin Cecchetto
// DATE: 2008-03-14
//***************************************************************************/

#pragma once

#ifndef STRICT
#define STRICT
#endif

#include "MaxWindowsVersion.h"

#include <windows.h>

