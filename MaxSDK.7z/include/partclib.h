#pragma once

#define IMPORTING
#include "particle.h"
#undef IMPORTING


