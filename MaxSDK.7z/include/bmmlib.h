#pragma once

#include "BMMExport.h"
#include "bitmap.h"
