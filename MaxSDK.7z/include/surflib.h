#pragma once

#define IMPORTING
#include "surf_api.h"
#undef IMPORTING